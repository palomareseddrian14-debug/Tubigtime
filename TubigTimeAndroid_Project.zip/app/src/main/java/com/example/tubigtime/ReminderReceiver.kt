package com.example.tubigtime

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val notification = NotificationCompat.Builder(context, "water_reminders")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Oras na para uminom! 💧")
            .setContentText("Kumuha ng isang basong tubig. Alagaan ang sarili!")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(context).notify(1001, notification) } catch (_: SecurityException) { }
        ReminderScheduler.schedule(context)
    }
}

object ReminderScheduler {
    fun schedule(context: Context) {
        val now = java.util.Calendar.getInstance()
        val next = (now.clone() as java.util.Calendar).apply {
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
            add(java.util.Calendar.HOUR_OF_DAY, 1)
            if (get(java.util.Calendar.HOUR_OF_DAY) < 9) {
                set(java.util.Calendar.HOUR_OF_DAY, 9)
            }
        }
        if (next.get(java.util.Calendar.HOUR_OF_DAY) > 21 ||
            (next.get(java.util.Calendar.HOUR_OF_DAY) == 21 &&
             (now.get(java.util.Calendar.HOUR_OF_DAY) >= 21))) {
            next.add(java.util.Calendar.DAY_OF_YEAR, 1)
            next.set(java.util.Calendar.HOUR_OF_DAY, 9)
        }
        val intent = Intent(context, ReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(context, 42, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            if (Build.VERSION.SDK_INT >= 31 && alarm.canScheduleExactAlarms()) {
                alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
            } else {
                alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
            }
        } catch (_: SecurityException) {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) ReminderScheduler.schedule(context)
    }
}
