package com.example.tubigtime

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("water", MODE_PRIVATE) }
    private lateinit var countText: TextView
    private lateinit var progressText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        askNotificationPermission()
        showHome()
        ReminderScheduler.schedule(this)
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(0xFFEAF7FF.toInt())
        }
        val title = TextView(this).apply {
            text = "💧 Tubig Time"
            textSize = 30f
            setTextColor(0xFF075985.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Small sips, healthy habits."
            textSize = 16f
            setPadding(0, 12, 0, 32)
            gravity = Gravity.CENTER
        }
        countText = TextView(this).apply {
            textSize = 24f
            setTextColor(0xFF0C4A6E.toInt())
            gravity = Gravity.CENTER
        }
        progressText = TextView(this).apply {
            textSize = 17f
            setPadding(0, 10, 0, 28)
            gravity = Gravity.CENTER
        }
        val add = Button(this).apply {
            text = "＋  Uminom ako (1 baso)"
            textSize = 18f
            setOnClickListener {
                val n = prefs.getInt("glasses", 0) + 1
                prefs.edit().putInt("glasses", n).putString("day", today()).apply()
                refreshCount()
                Toast.makeText(this@MainActivity, "Nice! Tuloy-tuloy lang 💙", Toast.LENGTH_SHORT).show()
            }
        }
        val reset = Button(this).apply {
            text = "I-reset ang bilang"
            setOnClickListener {
                prefs.edit().putInt("glasses", 0).putString("day", today()).apply()
                refreshCount()
            }
        }
        val schedule = Button(this).apply {
            text = "Paalala: 9:00 AM – 9:00 PM, bawat 1 oras"
            isAllCaps = false
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Paalala sa pag-inom")
                    .setMessage("Magpapadala ang Tubig Time ng notification bawat oras mula 9:00 AM hanggang 9:00 PM. Panatilihing naka-enable ang notifications para makatanggap ng paalala.")
                    .setPositiveButton("Okay", null).show()
            }
        }
        val permission = Button(this).apply {
            text = "Ayusin ang notification settings"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
                } catch (_: Exception) { }
            }
        }
        root.addView(title); root.addView(subtitle); root.addView(countText)
        root.addView(progressText); root.addView(add); root.addView(reset)
        root.addView(schedule); root.addView(permission)
        setContentView(root)
        refreshCount()
    }

    private fun refreshCount() {
        if (prefs.getString("day", "") != today()) {
            prefs.edit().putInt("glasses", 0).putString("day", today()).apply()
        }
        val n = prefs.getInt("glasses", 0)
        countText.text = "$n / 8 baso ngayong araw"
        progressText.text = "Tinatayang ${n * 250} mL na ang naitala mo\nTarget tracker: 8 baso (2,000 mL)"
    }

    private fun today() = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("water_reminders", "Water reminders", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "Hourly reminders to drink water"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }
}
