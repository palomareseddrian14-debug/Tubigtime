TUBIG TIME — Android app starter project

Included:
- Daily water-glass counter (1 tap = 1 glass / 250 mL)
- Daily tracker target of 8 glasses / 2,000 mL (editable in a future version)
- Hourly reminder schedule, 9:00 AM to 9:00 PM
- Notification channel and rescheduling after device restart

IMPORTANT:
This is the Android Studio source project, not a compiled APK. I cannot verify an APK build in this environment.
To build an APK:
1. Install Android Studio on a computer.
2. Open this TubigTimeAndroid folder in Android Studio.
3. Let Android Studio sync/download the Gradle and Android components.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.
6. Transfer the APK to your Samsung phone and install it. Allow installation from that source if Android asks.

Notes:
- Allow notifications when the app asks.
- Android battery-saving settings may delay reminders. Set the app battery use to Unrestricted if reminders are being delayed.
- Exact alarm permission behavior depends on Android version and device settings.
- The 8-glass/2-liter figure is only a simple tracker default, not a personalized medical hydration target.
